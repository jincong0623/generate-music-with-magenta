## JS实现五子棋 ##
根据慕课网上JS实现人工智能五子棋实现，后期进行了样式改造，加入了人人大战模块。
在线demo: [JS五子棋](http://www.tianhao.site/blog/gobang.html)
----------
