Beatrix
=======

![](logo.jpg)

Low-rez music HTML5 game for LOWREZ jam 2014

Play it online: [http://gamejolt.com/games/puzzle/beatrix/27454/](http://gamejolt.com/games/puzzle/beatrix/27454/)